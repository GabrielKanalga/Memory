/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Memory;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;

/**
 * FXML Controller class
 *
 * @author Gabriel Kanalga
 */
public class GameController implements Initializable {
  Random rnd = new Random();
    int c1V;
    int c2V;
    int c3V;
    int c4V;
    int c5V;
    int c6V;
    int c7V;
    int c8V;
    int c9V;
    int c10V;
    
    private List<Image> images = new ArrayList<>();
    private List<FileInputStream> streams = new ArrayList<>();
    @FXML
    private GridPane gPane;
    
    ImageView imageView;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      try {
          // TODO
          createStreams();
      } catch (FileNotFoundException ex) { 
          Logger.getLogger(GameController.class.getName()).log(Level.SEVERE, null, ex);
      }
      createImages();
    }    
        
    private void createStreams() throws FileNotFoundException{
        for(int i = 0; i < 10; i++){
            streams.add(new FileInputStream("src/Bilder/Monkey_" + (i + 1) + ".jpg"));
        }
    }
    
    private void createImages(){
        for(FileInputStream stream : streams){
            images.add(new Image(stream));
        }
        
        images.addAll(images);
        
        Collections.shuffle(images);
    }
    
    
    public void RandomPic() throws FileNotFoundException{
        for(int i = 0; i < gPane.getChildren().size(); i++){
            if(!gPane.getChildren().isEmpty()){
                imageView = (ImageView) gPane.getChildren().get(i);
            }
            else{
                continue;
            }
            
            imageView.setImage(images.get(i));
        }
      
        
    }

    @FXML
    private void clickmem(MouseEvent event) {
          for(int i = 0; i < gPane.getChildren().size(); i++){
            if(!gPane.getChildren().isEmpty()){
                imageView = (ImageView) gPane.getChildren().get(i);
            }
            else{
                continue;
            }
            
            imageView.setImage(images.get(i));
    }
    
}
}
