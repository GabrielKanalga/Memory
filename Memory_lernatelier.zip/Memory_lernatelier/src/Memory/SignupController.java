/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Memory;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Gabriel Kanalga
 */
public class SignupController implements Initializable {

    @FXML
    private TextField Login;
    @FXML
    private TextField Password;
    @FXML
    private Button Entersignup;
    
    private String pass;
    private String log;
    @FXML
    private Button returntolog;
    main mainclass = new main();

    SignupController(SignupController controller) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    private void Enter(ActionEvent event) {
        pass = Password.getText();
        log = Login.getText();
        Login.setVisible(false);
        Password.setVisible(false);
        
       
    }
    //
    
    public void getLogin(String ogin){
        if(ogin.equals(log)){
                mainclass.switchtgame(ogin);
              
       }
    }
    
    public void getPassword(String paswort){
        if(paswort.equals(pass)){
            mainclass.switchtgame(log);
        }
       
     
    }

    @FXML
    private void returntologin(ActionEvent event) {
        mainclass.switchtologin("login.fxml");
    }

    void setLogic(main aThis) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setModel(SignupController signupController) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
  
    
}
