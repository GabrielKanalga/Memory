/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Memory;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Gabriel Kanalga
 */
public class main extends Application {
    
    @Override
    public void start(Stage primaryStage) throws IOException {
        try{
     Parent root = FXMLLoader.load(getClass().getResource("game.fxml"));
     Scene scene = new Scene(root);
        
        primaryStage.setScene(scene);
        primaryStage.show();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
   
    public void switchtosignup(String fxmlFile)
    {
        FXMLLoader loader = new FXMLLoader(getClass()
            .getResource(fxmlFile));
    Parent root;
    try 
    {
        root = (Parent)loader.load();
        if(fxmlFile.equals("Signup.fxml"))
        {
            SignupController controller = (SignupController)loader.getController();
            controller.setModel(new SignupController(controller));
            controller.setLogic(this);
        }
        
        //this.primaryStage.setScene(new Scene(root));
    } 
    catch (IOException e)
    {
        e.printStackTrace();
    }
        
    }
     public void switchtologin(String fxmlFile)
             
    {
        
    }
     public void switchtgame(String fxmlFile)
    {
        
    }    
   

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    private class primaryStage {
        /*
        private static void setScene(Scene scene) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        public primaryStage() {
        }
*/
    }
    
}
