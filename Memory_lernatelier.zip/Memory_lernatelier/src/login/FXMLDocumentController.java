/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author Gabriel Kanalga
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private Button signup;
    @FXML
    private TextField password_a;
    @FXML
    private TextField login_a;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void Signupmethode(ActionEvent event) {
    }

    @FXML
    private void handelClose(MouseEvent event) {
    }

    @FXML
    private void signinbtn(ActionEvent event) {
    }
    
}
